export function UserSettings() {
  return (
    <div>
      <h2 className="text-2xl font-bold tracking-tight">Account Settings</h2>
      <p className="text-muted-foreground">Manage your account settings and preferences</p>
      {/* Account settings content will go here */}
    </div>
  )
}

