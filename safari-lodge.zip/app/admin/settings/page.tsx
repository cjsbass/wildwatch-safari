"use client"

import { useState } from "react"
import { Home, Camera, Bell, User } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { LodgeSettings } from "../components/lodge-settings"
import { CameraSettings } from "../components/camera-settings"
import { NotificationSettings } from "../components/notification-settings"
import { UserSettings } from "../components/user-settings"

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("lodges")

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Wildlife Notification System</h1>
      </div>

      <Alert className="mb-6 border-amber-200 bg-amber-50 dark:border-amber-900 dark:bg-amber-950">
        <AlertDescription className="text-amber-700 dark:text-amber-400">
          Changes to your lodge and camera settings may take up to 15 minutes to fully propagate through the system.
        </AlertDescription>
      </Alert>

      <div className="mb-4">
        <nav className="flex border rounded-md overflow-hidden">
          <button
            className={`flex items-center gap-1.5 px-3 py-2 text-sm ${
              activeTab === "lodges" ? "bg-background" : "bg-muted/30 hover:bg-muted/50"
            }`}
            onClick={() => setActiveTab("lodges")}
          >
            <Home className="h-4 w-4" />
            <span>Lodges</span>
          </button>
          <button
            className={`flex items-center gap-1.5 px-3 py-2 text-sm ${
              activeTab === "cameras" ? "bg-background" : "bg-muted/30 hover:bg-muted/50"
            }`}
            onClick={() => setActiveTab("cameras")}
          >
            <Camera className="h-4 w-4" />
            <span>Cameras</span>
          </button>
          <button
            className={`flex items-center gap-1.5 px-3 py-2 text-sm ${
              activeTab === "notifications" ? "bg-background" : "bg-muted/30 hover:bg-muted/50"
            }`}
            onClick={() => setActiveTab("notifications")}
          >
            <Bell className="h-4 w-4" />
            <span>Notifications</span>
          </button>
          <button
            className={`flex items-center gap-1.5 px-3 py-2 text-sm ${
              activeTab === "account" ? "bg-background" : "bg-muted/30 hover:bg-muted/50"
            }`}
            onClick={() => setActiveTab("account")}
          >
            <User className="h-4 w-4" />
            <span>Account</span>
          </button>
        </nav>
      </div>

      {activeTab === "lodges" && <LodgeSettings />}
      {activeTab === "cameras" && <CameraSettings />}
      {activeTab === "notifications" && <NotificationSettings />}
      {activeTab === "account" && <UserSettings />}
    </div>
  )
}

